'use strict';

/**
 * @ngdoc function
 * @name clientApp.controller:RewardsCtrl
 * @description
 * # RewardsCtrl
 * Controller of the clientApp
 */
angular.module('clientApp')
  .controller('RewardsCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
